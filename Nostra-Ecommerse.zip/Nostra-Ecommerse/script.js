const cartBtn = document.getElementById("cart-btn");
const cart = document.getElementById("cart");
const cartCount = document.getElementById("cart-count");
const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");
const searchInput = document.getElementById("search");
const categoryFilter = document.getElementById("category-filter");
const productList = document.getElementById("product-list");

let cartData = JSON.parse(localStorage.getItem("cart")) || [];

// Products (20 total: Electronics, Clothes, Accessories, Home Decor)
const products = [
  { name: "Smartphone", price: 499, category: "electronics", img: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=400&q=80" },
  { name: "Laptop", price: 899, category: "electronics", img: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&q=80" },
  { name: "Wireless Headphones", price: 120, category: "electronics", img: "https://images.unsplash.com/photo-1580894908361-9671950330d8?auto=format&fit=crop&w=400&q=80" },
  { name: "Smartwatch", price: 199, category: "electronics", img: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&q=80" },
  { name: "Tablet", price: 350, category: "electronics", img: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=400&q=80" },
  { name: "Bluetooth Speaker", price: 80, category: "electronics", img: "https://images.unsplash.com/photo-1512499617640-c2f99912e3ab?auto=format&fit=crop&w=400&q=80" },
  { name: "Gaming Console", price: 399, category: "electronics", img: "https://images.unsplash.com/photo-1612182061407-5de3d69f8fc2?auto=format&fit=crop&w=400&q=80" },
  { name: "DSLR Camera", price: 650, category: "electronics", img: "https://images.unsplash.com/photo-1509395176047-4a66953fd231?auto=format&fit=crop&w=400&q=80" },
  { name: "External Hard Drive", price: 100, category: "electronics", img: "https://images.unsplash.com/photo-1606813909895-8a1f8c2a7e99?auto=format&fit=crop&w=400&q=80" },
  { name: "VR Headset", price: 299, category: "electronics", img: "https://images.unsplash.com/photo-1606813909957-2b23a1680c29?auto=format&fit=crop&w=400&q=80" }
];


// Load products dynamically
function loadProducts(filter = "all", search = "") {
  productList.innerHTML = "";

  const filtered = products
    .filter(p => (filter === "all" || p.category === filter))
    .filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  if (filtered.length === 0) {
    productList.innerHTML = `<p style="padding:20px">No products found.</p>`;
    return;
  }

  filtered.forEach(p => {
    const div = document.createElement("div");
    div.classList.add("product");
    div.innerHTML = `
      <img src="${p.img}" alt="${p.name}">
      <h2>${p.name}</h2>
      <p>$${p.price}</p>
      <button class="add-to-cart" data-name="${p.name}" data-price="${p.price}">Add to Cart</button>
    `;
    productList.appendChild(div);
  });

  document.querySelectorAll(".add-to-cart").forEach(button => {
    button.addEventListener("click", () => {
      const name = button.dataset.name;
      const price = parseFloat(button.dataset.price);

      // Check if item exists in cart
      const existingItem = cartData.find(item => item.name === name);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cartData.push({ name, price, quantity: 1 });
      }

      saveCart();
      updateCart();
    });
  });
}

// Update cart UI with quantity
function updateCart() {
  cartItems.innerHTML = "";
  let total = 0;

  cartData.forEach((item, index) => {
    total += item.price * item.quantity;

    const li = document.createElement("li");
    li.innerHTML = `
      <span>${item.name} - $${item.price} x ${item.quantity} = $${(item.price*item.quantity).toFixed(2)}</span>
      <div>
        <button class="qty-btn" data-index="${index}" data-action="decrease">-</button>
        <button class="qty-btn" data-index="${index}" data-action="increase">+</button>
        <button class="remove-btn" data-index="${index}">X</button>
      </div>
    `;
    cartItems.appendChild(li);
  });

  cartCount.textContent = cartData.reduce((acc, i) => acc + i.quantity, 0);
  cartTotal.textContent = total.toFixed(2);

  // Quantity buttons
  document.querySelectorAll(".qty-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = Number(btn.dataset.index);
      if (btn.dataset.action === "increase") {
        cartData[idx].quantity += 1;
      } else if (btn.dataset.action === "decrease") {
        cartData[idx].quantity -= 1;
        if (cartData[idx].quantity <= 0) {
          cartData.splice(idx, 1);
        }
      }
      saveCart();
      updateCart();
    });
  });

  // Remove buttons
  document.querySelectorAll(".remove-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = Number(btn.dataset.index);
      cartData.splice(idx, 1);
      saveCart();
      updateCart();
    });
  });
}

// Save cart to localStorage
function saveCart() {
  localStorage.setItem("cart", JSON.stringify(cartData));
}

// Toggle cart sidebar
cartBtn.addEventListener("click", () => {
  cart.classList.toggle("active");
});

// Checkout
document.getElementById("checkout").addEventListener("click", () => {
  if (cartData.length === 0) {
    alert("Your cart is empty!");
    return;
  }
  alert("Thank you for your purchase!");
  cartData = [];
  saveCart();
  updateCart();
  cart.classList.remove("active"); // close cart after checkout
});

// Search filter
searchInput.addEventListener("input", () => {
  loadProducts(categoryFilter.value, searchInput.value);
});

// Category filter
categoryFilter.addEventListener("change", () => {
  loadProducts(categoryFilter.value, searchInput.value);
});

// Initial load
loadProducts();
updateCart();
